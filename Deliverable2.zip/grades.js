function addHtmlTableRow(){
var table = document.getElementById("myTable"),
newRow = table.insertRow(table.length),
cell1 = newRow.insertCell(0),
cell2 = newRow.insertCell(1),
cell3 = newRow.insertCell(2),
cell4 = newRow.insertCell(3),
cell5 = newRow.insertCell(4),

lastname = document.getElementById("lastname").value,
firstname = document.getElementById("firstname").value,
studentID = document.getElementById("studentID").value,
grade = document.getElementById("grade").value,
comment = document.getElementById("comment").value;

cell1.innerHTML = lastname;
cell2.innerHTML = firstname;
cell3.innerHTML = studentID;
cell4.innerHTML = grade;
cell5.innerHTML = comment;

}

function addHtmlTableRow2(){
    var table = document.getElementById("myTable2"),
    newRow = table.insertRow(table.length),
    cell1 = newRow.insertCell(0),
    cell2 = newRow.insertCell(1),
    cell3 = newRow.insertCell(2),
    cell4 = newRow.insertCell(3),
    cell5 = newRow.insertCell(4),
    
    lastname2 = document.getElementById("lastname2").value,
    firstname2 = document.getElementById("firstname2").value,
    studentID2 = document.getElementById("studentID2").value,
    grade2 = document.getElementById("grade2").value,
    comment2 = document.getElementById("comment2").value;
    
    cell1.innerHTML = lastname2;
    cell2.innerHTML = firstname2;
    cell3.innerHTML = studentID2;
    cell4.innerHTML = grade2;
    cell5.innerHTML = comment2;
    }
    function addHtmlTableRow3(){
        var table = document.getElementById("myTable3"),
        newRow = table.insertRow(table.length),
        cell1 = newRow.insertCell(0),
        cell2 = newRow.insertCell(1),
        cell3 = newRow.insertCell(2),
        cell4 = newRow.insertCell(3),
        cell5 = newRow.insertCell(4),
        
        lastname3 = document.getElementById("lastname3").value,
        firstname3 = document.getElementById("firstname3").value,
        studentID3 = document.getElementById("studentID3").value,
        grade3 = document.getElementById("grade3").value,
        comment3 = document.getElementById("comment3").value;
        
        cell1.innerHTML = lastname3;
        cell2.innerHTML = firstname3;
        cell3.innerHTML = studentID3;
        cell4.innerHTML = grade3;
        cell5.innerHTML = comment3;
        }
    function addHtmlTableRowMidterm(){
        var table = document.getElementById("myTableMidterm"),
        newRow = table.insertRow(table.length),
        cell1 = newRow.insertCell(0),
        cell2 = newRow.insertCell(1),
        cell3 = newRow.insertCell(2),
        cell4 = newRow.insertCell(3),
        cell5 = newRow.insertCell(4),
        
        lastname4 = document.getElementById("lastname4").value,
        firstname4 = document.getElementById("firstname4").value,
        studentID4 = document.getElementById("studentID4").value,
        grade4 = document.getElementById("grade4").value,
        comment4 = document.getElementById("comment4").value;
        
        cell1.innerHTML = lastname4;
        cell2.innerHTML = firstname4;
        cell3.innerHTML = studentID4;
        cell4.innerHTML = grade4;
        cell5.innerHTML = comment4;
        }
        function addHtmlTableRowFinal(){
            var table = document.getElementById("myTableFinal"),
            newRow = table.insertRow(table.length),
            cell1 = newRow.insertCell(0),
            cell2 = newRow.insertCell(1),
            cell3 = newRow.insertCell(2),
            cell4 = newRow.insertCell(3),
            cell5 = newRow.insertCell(4),
            
            lastname5 = document.getElementById("lastname5").value,
            firstname5 = document.getElementById("firstname5").value,
            studentID5 = document.getElementById("studentID5").value,
            grade5 = document.getElementById("grade5").value,
            comment5 = document.getElementById("comment5").value;
            
            cell1.innerHTML = lastname5;
            cell2.innerHTML = firstname5;
            cell3.innerHTML = studentID5;
            cell4.innerHTML = grade5;
            cell5.innerHTML = comment5;
            }
